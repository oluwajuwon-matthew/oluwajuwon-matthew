<div class="fixed-top">
<nav class="navbar navbar-expand-md bg-light navbar-light">
<!-- For the toggle collapse button -->
  <button class="navbar-toggler navbar-toggler-left" type="button" data-toggle="collapse"  data-target="#menu"><span class="navbar-toggler-icon" style="font-size: 14px;"></span></button>
    <div class="collapse navbar-collapse" id="menu">
      <ul class="navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="#">Home</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="#">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact Us</a>
        </li>
        
      </ul>
    </div>

  <span style="font-family: cursive; color: red; font-size: 24px;"><b><strong>Talent</strong></b></span><span style="color: black; font-family: sans-serif; font-size: 24px;"><strong><b>Display Form</b></strong></span>
  
</nav>
</div>