<?php
session_start();

// initializing variables
$name = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'Talent');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $name = mysqli_real_escape_string($db, $_POST['fullname']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $groupname = mysqli_real_escape_string($db, $_POST['groupname']);
  $address = mysqli_real_escape_string($db, $_POST['address']);
  $phone = mysqli_real_escape_string($db, $_POST['phone']);
  $contact = mysqli_real_escape_string($db, $_POST['contact']);
  $choice = mysqli_real_escape_string($db, $_POST['name']);


  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($name)) { array_push($errors, "Name is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($groupname)) { array_push($errors, "Groupname is required"); }
  if (empty($address)) { array_push($errors, "Address is required"); }
  if (empty($phone)) { array_push($errors, "Phone number is required"); }
  if (empty($choice)) { array_push($errors, "You need to pick atlesast three choices"); }
  
  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM user_info WHERE Name='$name' OR Email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['Name'] === $name) {
      array_push($errors, "Name already exists");
    }

    if ($user['Email'] === $email) {
      array_push($errors, "email already exists");
    }
      	header('location: register.php');

  } else {

  

  	$query = "INSERT INTO user_info (Name, email, Group_name, Address, Phone_number, Alternative_number, Area_of_interest) 
  			  VALUES('$name', '$email', '$groupname', '$address', '$phone', '$contact', '$choice')";
  	mysqli_query($db, $query);
  	$_SESSION['Name'] = $name;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: success.php');
  }
}

?>