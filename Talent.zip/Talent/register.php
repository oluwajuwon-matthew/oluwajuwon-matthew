<?php  include('server.php'); ?>
<!-- Source code for handling registration and login -->

<?php include('header.php'); ?>

<title>Talent Display Form</title>
</head>
<style type="text/css">
	body {
		background-image: url(tre.jpg);
		background-repeat: repeat all;
		background-position: center;
	}

input[type=Name] {
	background-color: white;
	border-radius: 20px;
}
input[type=email] {
	background-color: white;
	border-radius: 20px;
}
input[type=tel] {
	background-color: white;
	border-radius: 20px;
}
.input-group {
	background-color: white;
	border-radius: 4px;
	padding: 10px 30px;
}
fieldset {
	background-color: white;
	border-radius: 4px;
	padding: 10px 30px;
}
</style>
<body>
	<div class="container">
		<div class="col-md-4"></div>
	<!-- Navbar -->
		<?php include('navbar.php'); ?><br><br><br>
	<!-- // Navbar -->
<div class="col-md-4">
		<form method="post" action="register.php" >
			<img src="t.jpg" width="100%" height="200px" style="border-radius: 4px;"><br><br>
			
			<?php include('errors.php') ?>
			<div class="input-group">
			<label>Name: </label><br>
			<input type="Name" class="form-control" name="fullname" placeholder="Your answer" required></div><br>
			<div class="input-group">
			<label> Email: </label><br>
			<input type="email" name="email" class="form-control" value="<?php echo $email ?>" placeholder="Your Email" required></div><br>
			<div class="input-group">
			<label>School/Group name: </label><br>
			<input type="name" class="form-control" name="groupname" placeholder="Your answer" required></div><br>
			<div class="input-group">
			<label>Address: </label><br>
			<input type="name" class="form-control" name="address" placeholder="Your answer" required></div><br>
			<div class="input-group">
			<label> Phone number: </label><br>
			<input type="tel" class="form-control" name="phone" placeholder="Your answer" max="11" min="11" required></div><br>
			<div class="input-group">
			<label> Alternative contact person: <i>(Optional)</i> </label><br>
			<input type="tel" class="form-control" name="contact" placeholder="Your answer"  max="11" min="11"></div><br>
			<fieldset>
			<b>Please choose your area of interest:</b> 
			<p style="color: red;">You must select three choices</p><br>
			<div class="check">
			<input type="checkbox" name="name" placeholder="Your answer" value="Acting"> Acting<br>
			<input type="checkbox" name="name" placeholder="Your answer" value="Sport (Football)"> Sport (Football)<br>
			<input type="checkbox" name="name" placeholder="Your answer" value="Dance"> Dance<br>
			<input type="checkbox" name="name" placeholder="Your answer" value="Debate/Public speaking"> Debate/Public speaking<br>
			<input type="checkbox" name="name" placeholder="Your answer" value="Quiz (Current Affairs, Maths & Eng)"> Quiz (Current Affairs, Maths & Eng)<br>
			<input type="checkbox" name="name" placeholder="Your answer" value="Poetry"> Poetry<br>
			<input type="checkbox" name="name" placeholder="Your answer" value="Drawing/Painting"> Drawing/Painting<br>
			<input type="checkbox" name="name" placeholder="Your answer" value="Musical instrument"> Musical instrument<br>
			<input type="checkbox" name="name" placeholder="Your answer" value="Others"> Others<br><br>
			</div>
			<script type="text/javascript">
				$(document).ready(function(){
					$("input[name='name']").change(function(){
						var maxAllowed = 3;
						var cnt = $("input[name='name']:checked").length;
						if (cnt > maxAllowed) {
							$(this).prop("checked", "");
							alert('You can select maximum ' + maxAllowed + 'choices');
						}
					});
				});
			</script>
			</fieldset><br>
			
			<button type="submit" class="btn btn-primary" name="reg_user"><b>Register</b></button><br><br>
			
		</form>
	</div>
			<div class="col-md-4"></div>

	</div>
</div>

</body>
