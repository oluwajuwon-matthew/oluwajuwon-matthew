<?php  include('server.php'); ?>
<!-- Source code for handling registration and login -->

<?php include('header.php'); ?>

<title>Talent Display Form</title>
</head>